#ifndef SEARCH_TUTORIAL_4_H
#define SEARCH_TUTORIAL_4_H



#include "utility.h"

//------------------------------------------------------------------------------
//
// 4 - WHAT ARE THE OTHER BUTTONS?
//  Well done. Lets get over the other buttons left to the search bar really
//  quick.
//
// 5 - FORWARD AND BACKWARD
//  You can use the buttons to the very left to go forward and backward, like
//	in a web browser. They really come in handy in case you ask yourself 
//	something like "How did I end up here?"
//
// 6 - REFRESH
//  The next button allows you to refresh the project in case you changed some
//  of your code.
//
// 7 - HOME
//  This last button takes you back to the initial overview screen.
//
// 8 - WHAT'S NEXT?
//  Instead of the class activate the struct with the same name as before.
//
//------------------------------------------------------------------------------

namespace a
{
	class NameConflict
	{
	};
}



#endif // SEARCH_TUTORIAL_4_H

