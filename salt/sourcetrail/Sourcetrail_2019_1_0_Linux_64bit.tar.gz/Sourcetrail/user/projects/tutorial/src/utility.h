#ifndef UTILITY_H
#define UTILITY_H



typedef unsigned int uint;



#endif // UTILITY_H