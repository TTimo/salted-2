#ifndef STRING_H
#define STRING_H

class String
{
};

#endif // STRING_H
