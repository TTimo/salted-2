#ifndef SEARCH_TUTORIAL_5_H
#define SEARCH_TUTORIAL_5_H



#include "utility.h"

//------------------------------------------------------------------------------
//
// 9 - CONGRATULATONS
//  You have completed the challenge of search.
//  Oh, I almost forgot: You can only find nodes such as symbols via the search 
//  bar. It doesn't allow you to find edges like calls or inheritance. At least
//  not yet.
//  Try to get back to the the central hub using the search bar!
//
//------------------------------------------------------------------------------

namespace b
{
	struct NameConflict
	{
	};
}



#endif // SEARCH_TUTORIAL_5_H

