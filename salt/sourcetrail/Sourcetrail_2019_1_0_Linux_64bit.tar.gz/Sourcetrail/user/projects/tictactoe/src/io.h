#ifndef _IO_
#define _IO_

namespace io {

	int numberIn();
	void numberOut(int num);

	void stringOut(const char* str);

}

#endif // _IO_
