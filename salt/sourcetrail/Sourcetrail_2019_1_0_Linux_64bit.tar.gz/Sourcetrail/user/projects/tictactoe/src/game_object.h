#ifndef _GAME_OBJECT_
#define _GAME_OBJECT_

class GameObject {
public:
	GameObject() {}
	virtual ~GameObject() {}
};

#endif // _GAME_OBJECT_
