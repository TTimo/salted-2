#vs-sourcetrail

The Visual Studio extension source code is hosted at Github.

The extension is available in the Visual Studio Marketplace. To install this extension follow these steps:
* open Visual Studio
* from the menu bar select `Tools` -> `Extensions and Updates...`
* in the `Extensions and Updates` dialog choose `Online` -> `Visual Studio Gallery`
* press `Ctrl` + `E` and enter "Sourcetrail Extension" into the search bar
* click the install button

Link to the repository: [vs-sourcetrail](https://github.com/CoatiSoftware/vs-sourcetrail).
