#vim-sourcetrail

The Vim plugin is hosted at Github.

Link to the repository: [vim-sourcetrail](https://github.com/CoatiSoftware/vim-sourcetrail).
