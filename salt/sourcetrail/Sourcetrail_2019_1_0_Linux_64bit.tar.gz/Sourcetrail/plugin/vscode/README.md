#vsce-sourcetrail

The VS Code extension source code is hosted at Github.

The extension is available in the marketplace,
to install it simple use the marketplace inside VS Code

Link to the repository: [vsce-sourcetrail](https://github.com/CoatiSoftware/vsce-sourcetrail).
